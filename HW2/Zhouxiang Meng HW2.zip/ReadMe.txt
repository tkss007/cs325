Use Python 2.7
compile and run code by using python stoogesort.py -s