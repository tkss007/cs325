Use Python 2.7
compile and run code by using python insertsort.py -s and python mergesort.py -s